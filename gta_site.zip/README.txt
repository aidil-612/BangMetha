BangMetha - static site generated for user
How to use:
1. Unzip gta_site.zip
2. Upload the folder contents to a GitHub repo.
3. Ensure index.html is at the repo root.
4. Enable GitHub Pages in Settings -> Pages -> Deploy from branch: main, folder: / (root)
